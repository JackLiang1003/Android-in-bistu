package com.example.myapplication_03;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AddressActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address);
        //获取intent对象
        Intent intent = getIntent();
        //获取bundle信息
        Bundle bundle = intent.getExtras();

        //显示信息
        TextView admin = (TextView) findViewById(R.id.admin);
        admin.setText(bundle.getString("name"));
        TextView phone = (TextView) findViewById(R.id.phone);
        phone.setText(bundle.getString("num"));
        TextView address = (TextView) findViewById(R.id.address);
        address.setText(bundle.getString("province")+bundle.getString("city")+bundle.getString("county")+bundle.getString("detailed"));

        Button button = (Button)findViewById(R.id.yes);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //新建intent对象，回传处理后信息
                Intent intent1 = new Intent(AddressActivity.this, MainActivity.class);
                Bundle bundle1 = new Bundle();
                bundle1.putString("name", bundle.getString("name"));
                bundle1.putString("phone", bundle.getString("num"));
                bundle1.putString("address", (bundle.getString("province")+bundle.getString("city")+bundle.getString("county")+bundle.getString("detailed")));
                intent1.putExtras(bundle1);
                setResult(0, intent1);
                finish();
            }
        });

    }
}