package com.example.myapplication_03;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button) findViewById(R.id.send);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //获取输入信息
                String province = ((EditText)findViewById(R.id.province)).getText().toString();
                String city = ((EditText)findViewById(R.id.city)).getText().toString();
                String county = ((EditText)findViewById(R.id.county)).getText().toString();
                String detailed = ((EditText)findViewById(R.id.detailed)).getText().toString();
                String name = ((EditText)findViewById(R.id.name)).getText().toString();
                String numble = ((EditText)findViewById(R.id.numble)).getText().toString();

                if(( !"".equals(province) && !"".equals(city) && !"".equals(county)
                        && !"".equals(detailed) && !"".equals(name) && !"".equals(numble))) {
                    //省市县不同时为空，详细地址、姓名、电话号不能为空
                    //将输入信息保存到Bundle中，通过Intent传递
                    Intent intent = new Intent(MainActivity.this, AddressActivity.class);
                    //创建实例化Bundle对象
                    Bundle bundle = new Bundle();
                    bundle.putString("name", name);
                    bundle.putString("num", numble);
                    bundle.putString("province", province);
                    bundle.putString("city", city);
                    bundle.putString("county", county);
                    bundle.putString("detailed", detailed);
                    //将bundle对象添加到intent对象中
                    intent.putExtras(bundle);
                    startActivityForResult(intent, 0);      //启动activity
                }
                else{
                    //弹窗提示
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("内容不能为空");
                    builder.setPositiveButton("ok", null).show();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent){
        super.onActivityResult(requestCode, resultCode, intent);
        if(requestCode==0){
            //获取bundle信息
            Bundle bundle = intent.getExtras();

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("收货信息");
            builder.setMessage("姓名：" + bundle.getString("name") + "\n电话：" + bundle.getString("phone") + "\n地址：" + bundle.getString("address"));
            builder.setPositiveButton("ok", null).show();
        }
    }

}