package com.example.thread;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView textView=findViewById(R.id.answer);
        final Handler handler=new Handler(){
            @Override
            public void handleMessage(@NonNull Message msg) {
                textView.setText(msg.obj+"");
            }
        };
        final Runnable myWorker = new Runnable() {


            @Override
            public void run() {
                EditText editText=findViewById(R.id.input);
                int num=Integer.valueOf(editText.getText().toString().trim());
                int j=2;
                for(int i=2;i<=num;i++){
                    if(num%i==0)break;
                    else
                        j++;
                }
                if(j==num){
                    Message msg=new Message();
                    msg.obj="yes";
                    handler.sendMessage(msg);
                }
                else{
                    Message msg=new Message();
                    msg.obj="no";
                    handler.sendMessage(msg);
                }

            }
        };
        Button button=findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editText=findViewById(R.id.input);
                int num=Integer.valueOf(editText.getText().toString().trim());
                Thread workThread = new Thread(null, myWorker, "WorkThread");
                workThread.start();
            }
        });
    }
}